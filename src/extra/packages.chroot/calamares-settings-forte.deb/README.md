# calamares-settings-forte
based [calamares-settings-debian](https://salsa.debian.org/live-team/calamares-settings-debian)